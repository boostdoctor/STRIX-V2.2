Core/Src/ecu_wheels.o: ../Core/Src/ecu_wheels.c ../Core/Inc/ecu_wheels.h
../Core/Inc/ecu_wheels.h:
