Core/Src/ecu_settings.o: ../Core/Src/ecu_settings.c \
 ../Core/Inc/ecu_settings.h ../Core/Inc/ecu_flash.h
../Core/Inc/ecu_settings.h:
../Core/Inc/ecu_flash.h:
