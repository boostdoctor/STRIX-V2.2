################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/Src/dma.c \
../Core/Src/ecu_adc.c \
../Core/Src/ecu_app.c \
../Core/Src/ecu_cmd.c \
../Core/Src/ecu_decode.c \
../Core/Src/ecu_features.c \
../Core/Src/ecu_flash.c \
../Core/Src/ecu_fuel.c \
../Core/Src/ecu_idle.c \
../Core/Src/ecu_maps.c \
../Core/Src/ecu_outputs.c \
../Core/Src/ecu_runtime.c \
../Core/Src/ecu_sensors.c \
../Core/Src/ecu_serial.c \
../Core/Src/ecu_settings.c \
../Core/Src/ecu_spark.c \
../Core/Src/ecu_util.c \
../Core/Src/ecu_watchdog.c \
../Core/Src/ecu_wheels.c \
../Core/Src/main.c \
../Core/Src/stm32f4xx_hal_msp.c \
../Core/Src/stm32f4xx_it.c \
../Core/Src/syscalls.c \
../Core/Src/sysmem.c \
../Core/Src/system_stm32f4xx.c 

OBJS += \
./Core/Src/dma.o \
./Core/Src/ecu_adc.o \
./Core/Src/ecu_app.o \
./Core/Src/ecu_cmd.o \
./Core/Src/ecu_decode.o \
./Core/Src/ecu_features.o \
./Core/Src/ecu_flash.o \
./Core/Src/ecu_fuel.o \
./Core/Src/ecu_idle.o \
./Core/Src/ecu_maps.o \
./Core/Src/ecu_outputs.o \
./Core/Src/ecu_runtime.o \
./Core/Src/ecu_sensors.o \
./Core/Src/ecu_serial.o \
./Core/Src/ecu_settings.o \
./Core/Src/ecu_spark.o \
./Core/Src/ecu_util.o \
./Core/Src/ecu_watchdog.o \
./Core/Src/ecu_wheels.o \
./Core/Src/main.o \
./Core/Src/stm32f4xx_hal_msp.o \
./Core/Src/stm32f4xx_it.o \
./Core/Src/syscalls.o \
./Core/Src/sysmem.o \
./Core/Src/system_stm32f4xx.o 

C_DEPS += \
./Core/Src/dma.d \
./Core/Src/ecu_adc.d \
./Core/Src/ecu_app.d \
./Core/Src/ecu_cmd.d \
./Core/Src/ecu_decode.d \
./Core/Src/ecu_features.d \
./Core/Src/ecu_flash.d \
./Core/Src/ecu_fuel.d \
./Core/Src/ecu_idle.d \
./Core/Src/ecu_maps.d \
./Core/Src/ecu_outputs.d \
./Core/Src/ecu_runtime.d \
./Core/Src/ecu_sensors.d \
./Core/Src/ecu_serial.d \
./Core/Src/ecu_settings.d \
./Core/Src/ecu_spark.d \
./Core/Src/ecu_util.d \
./Core/Src/ecu_watchdog.d \
./Core/Src/ecu_wheels.d \
./Core/Src/main.d \
./Core/Src/stm32f4xx_hal_msp.d \
./Core/Src/stm32f4xx_it.d \
./Core/Src/syscalls.d \
./Core/Src/sysmem.d \
./Core/Src/system_stm32f4xx.d 


# Each subdirectory must supply rules for building sources it contributes
Core/Src/%.o Core/Src/%.su Core/Src/%.cyclo: ../Core/Src/%.c Core/Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F411xE -c -I../USB_DEVICE/App -I../USB_DEVICE/Target -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Middlewares/ST/STM32_USB_Device_Library/Core/Inc -I../Middlewares/ST/STM32_USB_Device_Library/Class/CDC/Inc -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Core-2f-Src

clean-Core-2f-Src:
	-$(RM) ./Core/Src/dma.cyclo ./Core/Src/dma.d ./Core/Src/dma.o ./Core/Src/dma.su ./Core/Src/ecu_adc.cyclo ./Core/Src/ecu_adc.d ./Core/Src/ecu_adc.o ./Core/Src/ecu_adc.su ./Core/Src/ecu_app.cyclo ./Core/Src/ecu_app.d ./Core/Src/ecu_app.o ./Core/Src/ecu_app.su ./Core/Src/ecu_cmd.cyclo ./Core/Src/ecu_cmd.d ./Core/Src/ecu_cmd.o ./Core/Src/ecu_cmd.su ./Core/Src/ecu_decode.cyclo ./Core/Src/ecu_decode.d ./Core/Src/ecu_decode.o ./Core/Src/ecu_decode.su ./Core/Src/ecu_features.cyclo ./Core/Src/ecu_features.d ./Core/Src/ecu_features.o ./Core/Src/ecu_features.su ./Core/Src/ecu_flash.cyclo ./Core/Src/ecu_flash.d ./Core/Src/ecu_flash.o ./Core/Src/ecu_flash.su ./Core/Src/ecu_fuel.cyclo ./Core/Src/ecu_fuel.d ./Core/Src/ecu_fuel.o ./Core/Src/ecu_fuel.su ./Core/Src/ecu_idle.cyclo ./Core/Src/ecu_idle.d ./Core/Src/ecu_idle.o ./Core/Src/ecu_idle.su ./Core/Src/ecu_maps.cyclo ./Core/Src/ecu_maps.d ./Core/Src/ecu_maps.o ./Core/Src/ecu_maps.su ./Core/Src/ecu_outputs.cyclo ./Core/Src/ecu_outputs.d ./Core/Src/ecu_outputs.o ./Core/Src/ecu_outputs.su ./Core/Src/ecu_runtime.cyclo ./Core/Src/ecu_runtime.d ./Core/Src/ecu_runtime.o ./Core/Src/ecu_runtime.su ./Core/Src/ecu_sensors.cyclo ./Core/Src/ecu_sensors.d ./Core/Src/ecu_sensors.o ./Core/Src/ecu_sensors.su ./Core/Src/ecu_serial.cyclo ./Core/Src/ecu_serial.d ./Core/Src/ecu_serial.o ./Core/Src/ecu_serial.su ./Core/Src/ecu_settings.cyclo ./Core/Src/ecu_settings.d ./Core/Src/ecu_settings.o ./Core/Src/ecu_settings.su ./Core/Src/ecu_spark.cyclo ./Core/Src/ecu_spark.d ./Core/Src/ecu_spark.o ./Core/Src/ecu_spark.su ./Core/Src/ecu_util.cyclo ./Core/Src/ecu_util.d ./Core/Src/ecu_util.o ./Core/Src/ecu_util.su ./Core/Src/ecu_watchdog.cyclo ./Core/Src/ecu_watchdog.d ./Core/Src/ecu_watchdog.o ./Core/Src/ecu_watchdog.su ./Core/Src/ecu_wheels.cyclo ./Core/Src/ecu_wheels.d ./Core/Src/ecu_wheels.o ./Core/Src/ecu_wheels.su ./Core/Src/main.cyclo ./Core/Src/main.d ./Core/Src/main.o ./Core/Src/main.su ./Core/Src/stm32f4xx_hal_msp.cyclo ./Core/Src/stm32f4xx_hal_msp.d ./Core/Src/stm32f4xx_hal_msp.o ./Core/Src/stm32f4xx_hal_msp.su ./Core/Src/stm32f4xx_it.cyclo ./Core/Src/stm32f4xx_it.d ./Core/Src/stm32f4xx_it.o ./Core/Src/stm32f4xx_it.su ./Core/Src/syscalls.cyclo ./Core/Src/syscalls.d ./Core/Src/syscalls.o ./Core/Src/syscalls.su ./Core/Src/sysmem.cyclo ./Core/Src/sysmem.d ./Core/Src/sysmem.o ./Core/Src/sysmem.su ./Core/Src/system_stm32f4xx.cyclo ./Core/Src/system_stm32f4xx.d ./Core/Src/system_stm32f4xx.o ./Core/Src/system_stm32f4xx.su

.PHONY: clean-Core-2f-Src

